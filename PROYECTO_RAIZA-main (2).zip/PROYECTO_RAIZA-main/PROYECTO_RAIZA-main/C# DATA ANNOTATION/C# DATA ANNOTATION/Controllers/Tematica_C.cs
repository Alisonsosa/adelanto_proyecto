﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repositories.Interfaces;
using RAIZA.Models;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TematicaController : ControllerBase
    {
        private readonly Tematica_I _tematicaRepository;

        public TematicaController(Tematica_I tematicaRepository)
        {
            _tematicaRepository = tematicaRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Tematica>>> GetTematicas()
        {
            var tematicas = await _tematicaRepository.GetTematicas();
            return Ok(tematicas);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Tematica>> GetTematicaById(int id)
        {
            var tematica = await _tematicaRepository.GetTematicaById(id);

            if (tematica == null)
            {
                return NotFound(new { mensaje = $"No se encontró la temática con ID {id}" });
            }

            return Ok(tematica);
        }

        [HttpPost]
        public async Task<ActionResult<Tematica>> CreateTematica([FromBody] Tematica tematica)
        {
            if (tematica == null)
            {
                return BadRequest("Los datos de la temática son obligatorios.");
            }

            var creada = await _tematicaRepository.CreateTematica(tematica);

            if (!creada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al guardar la temática.");
            }

            return CreatedAtAction(nameof(GetTematicaById), new { id = tematica.idtematica }, tematica);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateTematica(int id, [FromBody] Tematica tematica)
        {
            if (tematica == null || id != tematica.idtematica)
            {
                return BadRequest("El ID de la URL no coincide con el ID de la temática proporcionada.");
            }

            var existe = await _tematicaRepository.GetTematicaById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe la temática con ID {id}" });
            }

            var actualizada = await _tematicaRepository.UpdateTematica(tematica);

            if (!actualizada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar la temática.");
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteTematica(int id)
        {
            var eliminada = await _tematicaRepository.DeleteTematica(id);

            if (!eliminada)
            {
                return NotFound(new { mensaje = $"No se encontró la temática con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}