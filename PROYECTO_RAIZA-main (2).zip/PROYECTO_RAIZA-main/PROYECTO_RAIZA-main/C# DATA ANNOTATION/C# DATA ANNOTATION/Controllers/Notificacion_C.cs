﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repositories.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificacionController : ControllerBase
    {
        private readonly Notificacion_I _notificacionRepository;

        public NotificacionController(Notificacion_I notificacionRepository)
        {
            _notificacionRepository = notificacionRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Notificacion>>> GetNotificaciones()
        {
            var notificaciones = await _notificacionRepository.GetNotificaciones();
            return Ok(notificaciones);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Notificacion>> GetNotificacionById(int id)
        {
            var notificacion = await _notificacionRepository.GetNotificacionById(id);

            if (notificacion == null)
            {
                return NotFound(new { mensaje = $"No se encontró la notificación con ID {id}" });
            }

            return Ok(notificacion);
        }

        [HttpGet("usuario/{idUsuario:int}")]
        public async Task<ActionResult<List<Notificacion>>> GetNotificacionesByUsuarioId(int idUsuario)
        {
            var notificaciones = await _notificacionRepository.GetNotificacionesByUsuarioId(idUsuario);
            return Ok(notificaciones);
        }

        [HttpPost]
        public async Task<ActionResult<Notificacion>> CreateNotificacion([FromBody] Notificacion notificacion)
        {
            if (notificacion == null)
            {
                return BadRequest("Los datos de la notificación son obligatorios.");
            }

            var creada = await _notificacionRepository.CreateNotificacion(notificacion);

            if (!creada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al guardar la notificación.");
            }

            return CreatedAtAction(nameof(GetNotificacionById), new { id = notificacion.Idnotificacion }, notificacion);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateNotificacion(int id, [FromBody] Notificacion notificacion)
        {
            if (notificacion == null || id != notificacion.Idnotificacion)
            {
                return BadRequest("El ID de la URL no coincide con el ID de la notificación proporcionada.");
            }

            var existe = await _notificacionRepository.GetNotificacionById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe la notificación con ID {id}" });
            }

            var actualizada = await _notificacionRepository.UpdateNotificacion(notificacion);

            if (!actualizada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar la notificación.");
            }

            return NoContent();
        }

        [HttpPatch("{id:int}/marcar-leida")]
        public async Task<IActionResult> MarcarComoLeida(int id)
        {
            var resultado = await _notificacionRepository.MarcarComoLeida(id);

            if (!resultado)
            {
                return NotFound(new { mensaje = $"No se encontró la notificación con ID {id} para marcar como leída." });
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteNotificacion(int id)
        {
            var eliminada = await _notificacionRepository.DeleteNotificacion(id);

            if (!eliminada)
            {
                return NotFound(new { mensaje = $"No se encontró la notificación con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}