﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repositories.Interfaces;
using RAIZA.Models;


namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProgresoController : ControllerBase
    {
        private readonly Progreso_I _progresoRepository;

        public ProgresoController(Progreso_I progresoRepository)
        {
            _progresoRepository = progresoRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Progreso>>> GetProgresos()
        {
            var progresos = await _progresoRepository.GetProgresos();
            return Ok(progresos);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Progreso>> GetProgresoById(int id)
        {
            var progreso = await _progresoRepository.GetProgresoById(id);

            if (progreso == null)
            {
                return NotFound(new { mensaje = $"No se encontró el progreso con ID {id}" });
            }

            return Ok(progreso);
        }

        [HttpGet("estudiante/{idEstudiante:int}")]
        public async Task<ActionResult<List<Progreso>>> GetProgresosByEstudiante(int idEstudiante)
        {
            var progresos = await _progresoRepository.GetProgresosByEstudiante(idEstudiante);
            return Ok(progresos);
        }

        [HttpGet("estudiante/{idEstudiante:int}/modulo/{idModulo:int}")]
        public async Task<ActionResult<Progreso>> GetProgresoByEstudianteYModulo(int idEstudiante, int idModulo)
        {
            var progreso = await _progresoRepository.GetProgresoByEstudianteYModulo(idEstudiante, idModulo);

            if (progreso == null)
            {
                return NotFound(new { mensaje = "No se encontró el registro de progreso para el estudiante y módulo indicados." });
            }

            return Ok(progreso);
        }

        [HttpPost]
        public async Task<ActionResult<Progreso>> CreateProgreso([FromBody] Progreso progreso)
        {
            if (progreso == null)
            {
                return BadRequest("Los datos del progreso son obligatorios.");
            }

            var creado = await _progresoRepository.CreateProgreso(progreso);

            if (!creado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al guardar el progreso.");
            }

            return CreatedAtAction(nameof(GetProgresoById), new { id = progreso.idprogreso }, progreso);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateProgreso(int id, [FromBody] Progreso progreso)
        {
            if (progreso == null || id != progreso.idprogreso)
            {
                return BadRequest("El ID de la URL no coincide con el ID del progreso.");
            }

            var existe = await _progresoRepository.GetProgresoById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe el progreso con ID {id}" });
            }

            var actualizado = await _progresoRepository.UpdateProgreso(progreso);

            if (!actualizado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar el progreso.");
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteProgreso(int id)
        {
            var eliminado = await _progresoRepository.DeleteProgreso(id);

            if (!eliminado)
            {
                return NotFound(new { mensaje = $"No se encontró el progreso con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}