﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repositories.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly Usuario_I _usuarioRepository;

        public UsuarioController(Usuario_I usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Usuario>>> GetUsuarios()
        {
            var usuarios = await _usuarioRepository.GetUsuarios();
            return Ok(usuarios);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Usuario>> GetUsuarioById(int id)
        {
            var usuario = await _usuarioRepository.GetUsuarioById(id);

            if (usuario == null)
            {
                return NotFound(new { mensaje = $"No se encontró el usuario con ID {id}" });
            }

            return Ok(usuario);
        }

        [HttpPost]
        public async Task<ActionResult<Usuario>> CreateUsuario([FromBody] Usuario usuario)
        {
            if (usuario == null)
            {
                return BadRequest("Los datos del usuario son obligatorios.");
            }

            var creado = await _usuarioRepository.CreateUsuario(usuario);

            if (!creado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al guardar el usuario.");
            }

           
            return CreatedAtAction(nameof(GetUsuarioById), new { id = usuario.Id }, usuario);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateUsuario(int id, [FromBody] Usuario usuario)
        {
            if (usuario == null || id != usuario.Id)
            {
                return BadRequest("El ID de la URL no coincide con el ID del objeto.");
            }

            var existe = await _usuarioRepository.GetUsuarioById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe el usuario con ID {id}" });
            }

            var actualizado = await _usuarioRepository.UpdateUsuario(usuario);

            if (!actualizado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar el usuario.");
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            var eliminado = await _usuarioRepository.DeleteUsuario(id);

            if (!eliminado)
            {
                return NotFound(new { mensaje = $"No se encontró el usuario con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}