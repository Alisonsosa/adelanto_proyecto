﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repositories.Interfaces;
using RAIZA.Models;


namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TareaController : ControllerBase
    {
        private readonly Tarea_I _tareaRepository;

        public TareaController(Tarea_I tareaRepository)
        {
            _tareaRepository = tareaRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Tarea>>> GetTareas()
        {
            var tareas = await _tareaRepository.GetTareas();
            return Ok(tareas);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Tarea>> GetTareaById(int id)
        {
            var tarea = await _tareaRepository.GetTareaById(id);

            if (tarea == null)
            {
                return NotFound(new { mensaje = $"No se encontró la tarea con ID {id}" });
            }

            return Ok(tarea);
        }

        [HttpGet("modulo/{idModulo:int}")]
        public async Task<ActionResult<List<Tarea>>> GetTareasByModuloId(int idModulo)
        {
            var tareas = await _tareaRepository.GetTareasByModuloId(idModulo);
            return Ok(tareas);
        }

        [HttpPost]
        public async Task<ActionResult<Tarea>> CreateTarea([FromBody] Tarea tarea)
        {
            if (tarea == null)
            {
                return BadRequest("Los datos de la tarea son obligatorios.");
            }

            var creada = await _tareaRepository.CreateTarea(tarea);

            if (!creada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al guardar la tarea.");
            }

            return CreatedAtAction(nameof(GetTareaById), new { id = tarea.idtarea }, tarea);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateTarea(int id, [FromBody] Tarea tarea)
        {
            if (tarea == null || id != tarea.idtarea)
            {
                return BadRequest("El ID de la URL no coincide con el ID de la tarea proporcionada.");
            }

            var existe = await _tareaRepository.GetTareaById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe la tarea con ID {id}" });
            }

            var actualizada = await _tareaRepository.UpdateTarea(tarea);

            if (!actualizada)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar la tarea.");
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteTarea(int id)
        {
            var eliminada = await _tareaRepository.DeleteTarea(id);

            if (!eliminada)
            {
                return NotFound(new { mensaje = $"No se encontró la tarea con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}
    }
}