﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ModuloController(IModuloI moduloRepository) : ControllerBase
    {
        private readonly IModuloI _moduloRepository = moduloRepository;

        
        [HttpGet]
        public async Task<IActionResult> GetModulos()
        {
            var modulos = await _moduloRepository.GetModulos();
            return Ok(modulos);
        }

        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetModuloById(int id)
        {
            var modulo = await _moduloRepository.GetModuloById(id);

            if (modulo == null)
            {
                return NotFound(new { mensaje = "No se encontró el módulo." });
            }

            return Ok(modulo);
        }

        
        [HttpPost]
        public async Task<IActionResult> CreateModulo([FromBody] Modulo modulo)
        {
            if (modulo == null)
            {
                return BadRequest(new { mensaje = "Los datos del módulo son obligatorios." });
            }

            var resultado = await _moduloRepository.CreateModulo(modulo);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible crear el módulo." });
            }

            return CreatedAtAction(
                nameof(GetModuloById),
                new { id = modulo.idmodulo },
                modulo
            );
        }

        
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateModulo(int id, [FromBody] Modulo modulo)
        {
            if (modulo == null)
            {
                return BadRequest(new { mensaje = "Los datos del módulo son obligatorios." });
            }

            if (id != modulo.idmodulo)
            {
                return BadRequest(new { mensaje = "El ID de la URL no coincide con el ID del módulo." });
            }

            var moduloExistente = await _moduloRepository.GetModuloById(id);

            if (moduloExistente == null)
            {
                return NotFound(new { mensaje = "No se encontró el módulo." });
            }

            var resultado = await _moduloRepository.UpdateModulo(modulo);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible actualizar el módulo." });
            }

            return Ok(new
            {
                mensaje = "Módulo actualizado correctamente.",
                modulo = modulo
            });
        }

       
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteModulo(int id)
        {
            var modulo = await _moduloRepository.GetModuloById(id);

            if (modulo == null)
            {
                return NotFound(new { mensaje = "No se encontró el módulo." });
            }

            var resultado = await _moduloRepository.DeleteModulo(id);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible eliminar el módulo." });
            }

            return Ok(new { mensaje = "Módulo eliminado correctamente." });
        }
    }
}