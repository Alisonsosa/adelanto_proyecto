﻿using Microsoft.AspNetCore.Mvc;
using RAIZA.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeccionController : ControllerBase
    {
        private readonly ILeccionI _leccionRepository;

        public LeccionController(ILeccionI leccionRepository)
        {
            _leccionRepository = leccionRepository;
        }

        
        [HttpGet]
        public async Task<IActionResult> GetLecciones()
        {
            var lecciones = await _leccionRepository.GetLecciones();
            return Ok(lecciones);
        }

        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetLeccionById(int id)
        {
            var leccion = await _leccionRepository.GetLeccionById(id);

            if (leccion == null)
            {
                return NotFound(new { mensaje = "No se encontró la lección." });
            }

            return Ok(leccion);
        }

        
        [HttpPost]
        public async Task<IActionResult> CreateLeccion([FromBody] Leccion leccion)
        {
            if (leccion == null)
            {
                return BadRequest(new { mensaje = "Los datos de la lección son obligatorios." });
            }

            var resultado = await _leccionRepository.CreateLeccion(leccion);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible crear la lección." });
            }

            return CreatedAtAction(
                nameof(GetLeccionById),
                new { id = leccion.idleccion },
                leccion
            );
        }

        
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLeccion(int id, [FromBody] Leccion leccion)
        {
            if (leccion == null)
            {
                return BadRequest(new { mensaje = "Los datos de la lección son obligatorios." });
            }

            if (id != leccion.idleccion)
            {
                return BadRequest(new { mensaje = "El ID de la URL no coincide con el ID de la lección." });
            }

            var leccionExistente = await _leccionRepository.GetLeccionById(id);

            if (leccionExistente == null)
            {
                return NotFound(new { mensaje = "No se encontró la lección." });
            }

            var resultado = await _leccionRepository.UpdateLeccion(leccion);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible actualizar la lección." });
            }

            return Ok(new
            {
                mensaje = "Lección actualizada correctamente.",
                leccion = leccion
            });
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLeccion(int id)
        {
            var leccion = await _leccionRepository.GetLeccionById(id);

            if (leccion == null)
            {
                return NotFound(new { mensaje = "No se encontró la lección." });
            }

            var resultado = await _leccionRepository.DeleteLeccion(id);

            if (!resultado)
            {
                return BadRequest(new { mensaje = "No fue posible eliminar la lección." });
            }

            return Ok(new { mensaje = "Lección eliminada correctamente." });
        }
    }
}