﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RAIZA.Interfaces;
using RAIZA.Models;
using RAIZA.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RAIZA.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TareaController : ControllerBase
    {
        private readonly ITarea_I _tareaRepository;

        public TareaController(ITarea_I tareaRepository)
        {
            _tareaRepository = tareaRepository;
        }

        
        [HttpGet]
        public async Task<IActionResult> GetTareas()
        {
            var tareas = await _tareaRepository.GetTareas();
            return Ok(tareas);
        }

        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetTareaById(int id)
        {
            var tarea = await _tareaRepository.GetTareaById(id);

            if (tarea == null)
            {
                return NotFound(new
                {
                    mensaje = "No se encontró la tarea."
                });
            }

            return Ok(tarea);
        }

        
        [HttpPost]
        public async Task<IActionResult> CreateTarea([FromBody] Tarea tarea)
        {
            if (tarea == null)
            {
                return BadRequest(new
                {
                    mensaje = "Los datos de la tarea son obligatorios."
                });
            }

            var resultado = await _tareaRepository.CreateTarea(tarea);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible crear la tarea."
                });
            }

            return CreatedAtAction(
                nameof(GetTareaById),
                new { id = tarea.idtarea },
                tarea
            );
        }

        
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTarea(
            int id,
            [FromBody] Tarea tarea)
        {
            if (tarea == null)
            {
                return BadRequest(new
                {
                    mensaje = "Los datos de la tarea son obligatorios."
                });
            }

            if (id != tarea.idtarea)
            {
                return BadRequest(new
                {
                    mensaje = "El ID de la URL no coincide con el ID de la tarea."
                });
            }

            var tareaExistente = await _tareaRepository.GetTareaById(id);

            if (tareaExistente == null)
            {
                return NotFound(new
                {
                    mensaje = "No se encontró la tarea."
                });
            }

            var resultado = await _tareaRepository.UpdateTarea(tarea);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible actualizar la tarea."
                });
            }

            return Ok(new
            {
                mensaje = "Tarea actualizada correctamente.",
                tarea = tarea
            });
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTarea(int id)
        {
            var tarea = await _tareaRepository.GetTareaById(id);

            if (tarea == null)
            {
                return NotFound(new
                {
                    mensaje = "No se encontró la tarea."
                });
            }

            var resultado = await _tareaRepository.DeleteTarea(id);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible eliminar la tarea."
                });
            }

            return Ok(new
            {
                mensaje = "Tarea eliminada correctamente."
            });
        }
    }
}