﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RAIZA.Interfaces;
using RAIZA.Models;
using RAIZA.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RAIZA.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EntregaTareaController(IEntregaTareaI entregaTareaRepository) : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<List<EntregaTarea>>> GetEntregasTareas()
        {
            var entregas = await entregaTareaRepository.GetEntregasTareas();
            return Ok(entregas);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<EntregaTarea>> GetEntregaTareaById(int id)
        {
            var entrega = await entregaTareaRepository.GetEntregaTareaById(id);

            if (entrega == null)
            {
                return NotFound(new { mensaje = $"No se encontró la entrega de tarea con ID {id}." });
            }

            return Ok(entrega);
        }

        [HttpPost]
        public async Task<ActionResult<EntregaTarea>> CreateEntregaTarea([FromBody] EntregaTarea entregaTarea)
        {
            if (entregaTarea == null)
            {
                return BadRequest(new { mensaje = "Los datos de la entrega de tarea son obligatorios." });
            }

            var resultado = await entregaTareaRepository.CreateEntregaTarea(entregaTarea);

            if (!resultado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "No fue posible crear la entrega de tarea.");
            }

            return CreatedAtAction(
                nameof(GetEntregaTareaById),
                new { id = entregaTarea.IdEntregaTarea },
                entregaTarea
            );
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateEntregaTarea(int id, [FromBody] EntregaTarea entregaTarea)
        {
            if (entregaTarea == null || id != entregaTarea.IdEntregaTarea)
            {
                return BadRequest(new { mensaje = "El ID de la URL no coincide con el ID de la entrega de tarea." });
            }

            var entregaExistente = await entregaTareaRepository.GetEntregaTareaById(id);

            if (entregaExistente == null)
            {
                return NotFound(new { mensaje = $"No se encontró la entrega de tarea con ID {id}." });
            }

            var resultado = await entregaTareaRepository.UpdateEntregaTarea(entregaTarea);

            if (!resultado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "No fue posible actualizar la entrega de tarea.");
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteEntregaTarea(int id)
        {
            var resultado = await entregaTareaRepository.DeleteEntregaTarea(id);

            if (!resultado)
            {
                return NotFound(new { mensaje = $"No se encontró la entrega de tarea con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}