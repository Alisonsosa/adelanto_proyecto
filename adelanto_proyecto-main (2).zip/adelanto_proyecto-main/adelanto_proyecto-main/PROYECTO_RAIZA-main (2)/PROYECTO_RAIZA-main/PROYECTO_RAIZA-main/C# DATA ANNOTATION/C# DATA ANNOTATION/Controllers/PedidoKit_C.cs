﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Repository.Interfaces;
using RAIZA.Models;

namespace RAIZA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoKitController : ControllerBase
    {
        private readonly PedidoKit_I _pedidoKitRepository;

        public PedidoKitController(PedidoKit_I pedidoKitRepository)
        {
            _pedidoKitRepository = pedidoKitRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidoKit>>> GetPedidosKit()
        {
            var pedidos = await _pedidoKitRepository.GetPedidosKit();
            return Ok(pedidos);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<PedidoKit>> GetPedidoKitById(int id)
        {
            var pedido = await _pedidoKitRepository.GetPedidoKitById(id);

            if (pedido == null)
            {
                return NotFound(new { mensaje = $"No se encontró el pedido con ID {id}" });
            }

            return Ok(pedido);
        }

        [HttpGet("estudiante/{idEstudiante:int}")]
        public async Task<ActionResult<List<PedidoKit>>> GetPedidosByEstudianteId(int idEstudiante)
        {
            var pedidos = await _pedidoKitRepository.GetPedidosByEstudianteId(idEstudiante);
            return Ok(pedidos);
        }

        [HttpPost]
        public async Task<ActionResult<PedidoKit>> CreatePedidoKit([FromBody] PedidoKit pedidoKit)
        {
            if (pedidoKit == null)
            {
                return BadRequest("Los datos del pedido son obligatorios.");
            }

            var creado = await _pedidoKitRepository.CreatePedidoKit(pedidoKit);

            if (!creado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al procesar el pedido.");
            }

            return CreatedAtAction(nameof(GetPedidoKitById), new { id = pedidoKit.idPedidoKit }, pedidoKit);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdatePedidoKit(int id, [FromBody] PedidoKit pedidoKit)
        {
            if (pedidoKit == null || id != pedidoKit.idPedidoKit)
            {
                return BadRequest("El ID de la URL no coincide con el ID del pedido.");
            }

            var existe = await _pedidoKitRepository.GetPedidoKitById(id);
            if (existe == null)
            {
                return NotFound(new { mensaje = $"No existe el pedido con ID {id}" });
            }

            var actualizado = await _pedidoKitRepository.UpdatePedidoKit(pedidoKit);

            if (!actualizado)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error al actualizar el pedido.");
            }

            return NoContent();
        }

        [HttpPatch("{id:int}/estado")]
        public async Task<IActionResult> CambiarEstadoPedido(int id, [FromBody] string nuevoEstado)
        {
            if (string.IsNullOrWhiteSpace(nuevoEstado))
            {
                return BadRequest("El estado no puede estar vacío.");
            }

            var actualizado = await _pedidoKitRepository.CambiarEstadoPedido(id, nuevoEstado);

            if (!actualizado)
            {
                return NotFound(new { mensaje = $"No se encontró el pedido con ID {id} para actualizar su estado." });
            }

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeletePedidoKit(int id)
        {
            var eliminado = await _pedidoKitRepository.DeletePedidoKit(id);

            if (!eliminado)
            {
                return NotFound(new { mensaje = $"No se encontró el pedido con ID {id} para eliminar." });
            }

            return NoContent();
        }
    }
}