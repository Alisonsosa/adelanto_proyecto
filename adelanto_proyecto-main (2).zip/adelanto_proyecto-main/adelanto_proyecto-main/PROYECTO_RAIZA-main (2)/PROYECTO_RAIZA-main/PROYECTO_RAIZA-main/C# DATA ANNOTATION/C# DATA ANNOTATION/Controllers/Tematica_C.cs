﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using RAIZA.Interfaces;
using RAIZA.Models;



namespace RAIZA.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TematicaController : ControllerBase
    {
        private readonly ITematicaI _tematicaRepository;

        public TematicaController(ITematicaI tematicaRepository)
        {
            _tematicaRepository = tematicaRepository;
        }

        // GET: api/Tematica
        [HttpGet]
        public async Task<IActionResult> GetTematicas()
        {
            var tematicas = await _tematicaRepository.GetTematicas();

            return Ok(tematicas);
        }

        // GET: api/Tematica/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetTematicaById(int id)
        {
            var tematica = await _tematicaRepository.GetTematicaById(id);

            if (tematica == null)
            {
                return NotFound(new
                {
                    mensaje = "La temática no fue encontrada."
                });
            }

            return Ok(tematica);
        }

        // POST: api/Tematica
        [HttpPost]
        public async Task<IActionResult> CreateTematica([FromBody] Tematica tematica)
        {
            if (tematica == null)
            {
                return BadRequest(new
                {
                    mensaje = "Los datos de la temática son obligatorios."
                });
            }

            var resultado = await _tematicaRepository.CreateTematica(tematica);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible crear la temática."
                });
            }

            return Ok(new
            {
                mensaje = "Temática creada correctamente.",
                tematica = tematica
            });
        }

        // PUT: api/Tematica/1
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTematica(
            int id,
            [FromBody] Tematica tematica)
        {
            if (tematica == null)
            {
                return BadRequest(new
                {
                    mensaje = "Los datos de la temática son obligatorios."
                });
            }

            if (id != tematica.idtematica)
            {
                return BadRequest(new
                {
                    mensaje = "El ID de la URL no coincide con el ID de la temática."
                });
            }

            var tematicaExistente =
                await _tematicaRepository.GetTematicaById(id);

            if (tematicaExistente == null)
            {
                return NotFound(new
                {
                    mensaje = "La temática no fue encontrada."
                });
            }

            var resultado =
                await _tematicaRepository.UpdateTematica(tematica);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible actualizar la temática."
                });
            }

            return Ok(new
            {
                mensaje = "Temática actualizada correctamente.",
                tematica = tematica
            });
        }

        // DELETE: api/Tematica/1
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTematica(int id)
        {
            var tematica =
                await _tematicaRepository.GetTematicaById(id);

            if (tematica == null)
            {
                return NotFound(new
                {
                    mensaje = "La temática no fue encontrada."
                });
            }

            var resultado =
                await _tematicaRepository.DeleteTematica(id);

            if (!resultado)
            {
                return BadRequest(new
                {
                    mensaje = "No fue posible eliminar la temática."
                });
            }

            return Ok(new
            {
                mensaje = "Temática eliminada correctamente."
            });
        }
    }
}