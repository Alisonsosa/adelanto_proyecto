﻿namespace RAIZA.Controllers
{
    internal interface ITematica_I
    {
    }
}